#!/usr/bin/env python3
#
# python-v4l2capture
#
# This file is an example on how to capture a mjpeg video with
# python-v4l2capture.
#
# 2009, 2010 Fredrik Portstrom
#
# I, the copyright holder of this file, hereby release it into the
# public domain. This applies worldwide. In case this is not legally
# possible: I grant anyone the right to use this work for any
# purpose, without any conditions, unless such conditions are
# required by law.


import select
import v4l2capture
import time
import cv2
import numpy as np
#import imgbot

from PIL import Image
#import cv2

# Open the video device.
video = v4l2capture.Video_device("/dev/video0")

# Suggest an image size to the device. The device may choose and
# return another size if it doesn't support the suggested one.
#size_x, size_y = video.set_format(640, 480, fourcc='MJPG')

size_x, size_y = video.set_format(1280, 1024, fourcc='RGB3')

# Create a buffer to store image data in. This must be done before
# calling 'start' if v4l2capture is compiled with libv4l2. Otherwise
# raises IOError.
video.create_buffers(30)

# Send the buffer to the device. Some devices require this to be done
# before calling 'start'.
video.queue_all_buffers()

# Start the device. This lights the LED if it's a camera that has one.
video.start()

stop_time = time.time() + 10.0
with open('video.mp4', 'wb') as f:
    while stop_time >= time.time():
        # Wait for the device to fill the buffer.
        select.select((video,), (), ())

        # The rest is easy :-)
        image_data = video.read_and_queue()
        
        f.write(image_data)
        image = Image.frombytes("RGB", (size_x, size_y), image_data)
        print("The actual Image size",np.size(image))
        result = cv2.VideoWriter('filename.avi',cv2.VideoWriter_fourcc(*'MJPG'),10,(size_x,size_y)) 
        img2=np.array(image)
        result.write(img2)
    result.release()

        #image.show()
        #imgbot.imgread(image)


       # cv2.imshow('Input',image)
        #c=cv2.waitkey(1)
        #if c==27:
         #  break

       
        
    
video.close()
      
print("Saved video.mp4 (Size: " + str(size_x) + " x " + str(size_y) + ")")
