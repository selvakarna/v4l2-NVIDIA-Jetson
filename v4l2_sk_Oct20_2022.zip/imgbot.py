import cv2
import numpy as np



def imgread(img):
    while(True):
       frame_width=1280
       frame_height=1024
       img_size=np.size(img)
 
       size = (frame_width, frame_height)
       result = cv2.VideoWriter('filename.mp4',cv2.VideoWriter_fourcc(*'MJPG'),60, size) 
       img2=np.array(img)
    #img2=np.float32(img)
   # print('Type',type(img2))

                         
       result.write(img2)
    result.release()



 
   
      

  



