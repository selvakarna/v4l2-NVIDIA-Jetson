

from PIL import Image
import select
import v4l2capture
import cv2
import numpy as np
# Open the video device.
video = v4l2capture.Video_device("/dev/video0")

# Suggest an image size to the device. The device may choose and
# return another size if it doesn't support the suggested one.
size_x, size_y = video.set_format(1920, 1080) #(1280, 1024)

# Create a buffer to store image data in. This must be done before
# calling 'start' if v4l2capture is compiled with libv4l2. Otherwise
# raises IOError.
video.create_buffers(1)   # for image one buffer 

# Send the buffer to the device. Some devices require this to be done
# before calling 'start'.
video.queue_all_buffers()

# Start the device. This lights the LED if it's a camera that has one.
video.start()

# Wait for the device to fill the buffer.
# select.select((video,), (), ())

# The rest is easy :-)
# image_data = video.read()
# video.close()
# image = Image.frombytes("RGB", (size_x, size_y), image_data)
# print("The fps is.............",video.get_info)
while(True):
    select.select((video,), (), ())
    # image_data = video.read()
    image_data = video.read_and_queue()
  
    # if ret == True: 

           
    image = Image.frombytes("RGB", (size_x, size_y), image_data)

    img2=np.array(image)
    cv2.imshow('Input',img2)
    if cv2.waitKey(1) & 0xFF == ord('s'):
                break
    # else:
    #         break
video.release()
result.release()
    
# Closes all the frames
cv2.destroyAllWindows()
# c=cv2.waitKey(0)
# if c==27:
#     break
    
# print("The image size is",np.size(image))
# image.save("image.jpg")
# print("Saved image.jpg (Size: " + str(size_x) + " x " + str(size_y) + ")")
